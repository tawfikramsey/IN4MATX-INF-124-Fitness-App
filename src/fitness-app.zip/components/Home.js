// src/components/Home.js
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to the Homepage</h1>
      <p>You have successfully logged in!</p>
    </div>
  );
}

export default Home;
